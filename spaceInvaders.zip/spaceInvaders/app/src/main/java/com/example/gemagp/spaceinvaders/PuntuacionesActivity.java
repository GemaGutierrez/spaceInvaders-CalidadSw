package com.example.gemagp.spaceinvaders;

import android.app.ListActivity;
import android.os.Bundle;

public class PuntuacionesActivity extends ListActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.puntuaciones);
    }
}
